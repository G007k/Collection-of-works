using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : MonoBehaviour
{
    public float attack;
    public float attackSpeed;
    public float attackRange;
    public Transform target;
    public float rotateSpeed;
    public float lastShoot;
    public float recharge;
    public int expend;
    public List<Transform>muzzle;
    public Transform turret;
    public GameObject bullet;
    private EnemyManager enemyManager;
    // Start is called before the first frame update
    void Start()
    {
        enemyManager = GameObject.Find("EnemyManager").GetComponent<EnemyManager>();
    }

    // Update is called once per frame
    void Update()
    {
        if(turret==null)
        {
            return;
        }
        GetAttackTarget();
        RoateAttack();
        Shooting();
    }
    void GetAttackTarget()
    {
        if(target!=null)
        {
            if(Vector3.Distance(target.position,transform.position)<=attackRange)
            {
                return;
            }
            else
            {
                target = null;
                return;
            }
        }
        for(int i = 0;i < enemyManager.enemyList.Count;i++)
        {
            GameObject enemy=enemyManager.enemyList[i];
            if(Vector3.Distance(enemy.transform.position,transform.position)<=attackRange)
            {
                target = enemy.transform;
                return;
            }
        }
    }
    void RoateAttack()
    {
        if(target!=null)
        {
            Quaternion qua=Quaternion.FromToRotation(Vector3.forward,target.transform.position - turret.position);
            Quaternion rot=Quaternion.Lerp(turret.rotation,qua,Time.deltaTime * rotateSpeed * attackSpeed);
            transform.eulerAngles=new Vector3(transform.eulerAngles.x,rot.eulerAngles.y,transform.eulerAngles.z);
            turret.eulerAngles=new Vector3(rot.eulerAngles.x,turret.eulerAngles.y,turret.eulerAngles.z);
        }
    }
    void Shooting()
    {
        if(target!=null)
        {
            Vector3 a = target.position - turret.position + turret.forward;
            Vector3 b = target.position - turret.position;
            if(Vector3.Angle(a,b)<=10)
            {
                if(Time.time - lastShoot <= recharge / attackSpeed)
                {
                    return;
                }
                if(bullet!=null)
                {
                    lastShoot = Time.time;
                    for(int i = 0; i < muzzle.Count; i++)
                    {
                        GameObject go = GameObject.Instantiate(bullet);
                        go.tag = "Bullet";
                        go.transform.position = muzzle[i].transform.position;
                        go.transform.localScale*= 0.1f;
                        go.transform.eulerAngles = muzzle[i].eulerAngles;
                        AudioSource audioSource = go.AddComponent<AudioSource>();
                        audioSource.clip = Resources.Load<AudioClip>("audio/attcak");
                        audioSource.Play();
                    }
                }
            }
        }
    }   
       public void DestroyTower()
        {
            GameData.instance.coins = GameData.instance.coins + (int)(expend * 0.7f);
            GameObject.Find("Canvas").GetComponent<UIManager>().UpadataBattleUI();
            Destroy(this.gameObject);
        }
}    
   
