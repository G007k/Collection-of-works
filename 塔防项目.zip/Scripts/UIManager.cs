using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    public Transform mainPage;
    public Button startBtn;
    public Button settingBtn;
    public Button quitBtn;
    public Transform battlPage;
    public Sprite pauseSprite;
    public Sprite continueSprite;
    public Button pauseBtn;
    public Transform gameTips;
    public Text gameTipsText;
    public Text homeHP;
    public Text killText;
    public Text enemyText;
    public Text coinText;
    public Text timeText;
    public Transform  failPage;
    public Button restartBtn;
    public Button[] towerButtons;
    private Button lastBtn;
    private TowerManager towerManager;
    // Start is called before the first frame update
    void Start()
    {
       startBtn.onClick.AddListener(OnClickStartBtn) ;
       quitBtn.onClick.AddListener(OnClickQuitBtn);
       pauseBtn.onClick.AddListener(OnClickPauseBtn);
       restartBtn.onClick.AddListener(OnClickRestartBtn);
       towerManager = GameObject.Find("TowerManager").GetComponent<TowerManager>();
       towerManager.enabled = false;
       for(int i = 0;i < towerButtons.Length;i++)
       {
        int index = i;
        Button btn = towerButtons[i];
        btn.onClick.AddListener(() =>
        {
            towerManager.selectIndex = index;
            if(lastBtn != null)
            {
                lastBtn.GetComponent<Image>().color = new Color(0,0,0,0.7f);
            }
            btn.gameObject.GetComponent<Image>().color = Color.yellow;
            lastBtn = btn;
        });
       }
       towerManager.selectIndex = 0;
       towerButtons[0].gameObject.GetComponent<Image>().color = Color.yellow;
       lastBtn=towerButtons[0];
       for(int i = 0;i < towerManager.towerPrefabList.Count;i++)
       {
        int expend=towerManager.towerPrefabList[i].GetComponent<Tower>().expend;
        towerButtons[i].transform.Find("Text(Legacy)").GetComponent<Text>().text = expend.ToString();
       }
    }
    private void OnClickRestartBtn()
    {
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }

    private void OnClickPauseBtn()
    {
        if(Time.timeScale==1)
        {
            Time.timeScale = 0;
            pauseBtn.GetComponent<Image>().sprite = continueSprite;
        }
        else
        {
            Time.timeScale = 1;
            pauseBtn.GetComponent<Image>().sprite = pauseSprite;
        }
    }

    private void OnClickQuitBtn()
    {
        Application.Quit();
    }

    // Update is called once per frame
    private void OnClickStartBtn()
    {
        mainPage.gameObject.SetActive(false);
        battlPage.gameObject.SetActive(true);
        GameData.instance.SetData(1);
        UpadataBattleUI();
        timeText.text = "00:00";
        StartCoroutine(routine:CountDown());
        Camera.main.GetComponent<CameraManager>().GameStart();
    }
    public void UpadataBattleUI()
    {
        homeHP.text = GameData.instance.homeHP.ToString();
        killText.text = GameData.instance.killCount.ToString();
        enemyText.text = GameData.instance.enemyCount.ToString();
        coinText.text = GameData.instance.coins.ToString();
    }
    IEnumerator CountDown()
    {
        gameTips.gameObject.SetActive(true);
        for(int i = 0;i < 5;i++)
        {
            gameTipsText.text = $"怪物即将到来，请准备!{5-i}";
            yield return new WaitForSeconds(1);
        }
        gameTipsText.text = "";
        gameTips.gameObject.SetActive(false);
        GameObject.Find("EnemyManager").GetComponent<EnemyManager>().enabled = true;
        towerManager.enabled = true;
        // 显示游戏进行时长
        while(GameData.instance.homeHP > 0)
        {
            yield return new WaitForSeconds(1.0f);
            GameData.instance.time++;
            float second=GameData.instance.time%60;
            timeText.text = $"{(int)(GameData.instance.time / 60)}:{second:00}";
        }
    }
    public void ShowGameReult(bool isWin)
    {
        if(!isWin)
        {
            failPage.gameObject.SetActive(true);
            Camera.main.GetComponent<CameraManager>().GameOver();
        }
        else
        {
            Debug.Log("游戏胜利");
        }
    }
    public void CoinTips()
        {
        GameObject tips = GameObject.Instantiate(gameTips.gameObject);
        tips.transform.SetParent(gameTips.parent);
        Text t=tips.transform.Find("Text (Legacy)").GetComponent<Text>();
        t.text = "金币不足";
        tips.transform.position=gameTips.position;
        tips.gameObject.AddComponent<MoveTween>();
        tips.gameObject.SetActive(true);
        }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.A))
        {
            ShowGameReult(isWin:false);
        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            CoinTips();
        }
    }
}

