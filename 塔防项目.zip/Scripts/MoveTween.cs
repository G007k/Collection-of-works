using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveTween : MonoBehaviour
{
    private float moveSpeed = 100;
    private float time = 2;
    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject,time);
    }

    // Update is called once per frame
    void Update()
    {
        this.GetComponent<RectTransform>().anchoredPosition += new Vector2(0,moveSpeed * Time.deltaTime);
    }
}
