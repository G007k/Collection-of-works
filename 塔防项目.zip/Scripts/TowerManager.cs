using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class TowerManager : MonoBehaviour
{
    public List<GameObject> towerPrefabList;
    public int selectIndex;
    private UIManager uiManager;
    // Start is called before the first frame update
    void Start()
    {
        uiManager=GameObject.Find("Canvas").GetComponent<UIManager>();
    }

    // Update is called once per frame
    void Update()
    {
        CreateTower();
        DestroyTower();
    }
    public void CreateTower()
    {
        if(Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if(Physics.Raycast(ray,out hit,100,LayerMask.GetMask("TowerBase")))
            {
                TowerBase towerBase = hit.transform.GetComponent<TowerBase>();
                if(towerBase!=null&&towerBase.tower==null)
                {
                    GameObject towerObj=GameObject.Instantiate(towerPrefabList[selectIndex]);
                    Tower tower = towerObj.GetComponent<Tower>();
                    if(GameData.instance.coins>=tower.expend)
                    {
                    towerObj.transform.position = towerBase.towerPosition.position;
                    towerObj.transform.eulerAngles=hit.transform.eulerAngles;
                    towerObj.transform.parent = towerBase.transform;
                    towerBase.tower = towerObj;
                    GameData.instance.coins -= tower.expend;
                    uiManager.UpadataBattleUI();
                    }
                    else
                    {
                        uiManager.CoinTips();
                    }
                }
            }
        }
    }
    public void DestroyTower()
    {
        if(Input.GetMouseButtonDown(2))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if(Physics.Raycast(ray,out hit))
            {
               if(hit.collider.gameObject.CompareTag("Tower"))
               {
                Tower tower = hit.transform.GetComponent<Tower>();
                if(tower != null)
                {
                  tower.transform.GetComponentInParent<TowerBase>().tower = null;
                  tower.DestroyTower();
                }
               }
                if(hit.collider.gameObject.CompareTag("Effect"))
                {
                Tower tower = hit.transform.GetComponentInParent<Tower>();
                if(tower != null)
                {
                  tower.transform.GetComponentInParent<TowerBase>().tower = null;
                  tower.DestroyTower();
                }
                }
            }
        }
    }
}          

