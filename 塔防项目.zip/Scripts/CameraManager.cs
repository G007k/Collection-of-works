using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    private Camera mainCamera;
        private Vector3 startPos = new Vector3(65.75f,186.9f,111.4f);
        private float speed = 8;
        private bool isGameStart;
    // Start is called before the first frame update
    void Start()
    {
        mainCamera = this.GetComponent<Camera>();
        transform.position = startPos;
        mainCamera.fieldOfView = 60;
        
    }

    // Update is called once per frame
    void Update()
    {
        if(!isGameStart)
        {
            return;
        }
        MoveCamera();
        CameraZoom();
    }
    public void MoveCamera()
    {
        if(Input.GetMouseButton(1))
        {
            float mouseX = Input.GetAxis("Mouse X");
            float mouseY = Input.GetAxis("Mouse Y");
            if(mouseX!=0||mouseY!=0)
            {
                Vector3 target=transform.position+new Vector3(mouseX,0,mouseY)*speed;
                transform.position = Vector3.Lerp(transform.position,target,speed*Time.deltaTime);
            }
        }
    }
    public void CameraZoom()
    {
        float zoom = Input.GetAxis("Mouse ScrollWheel");
        if(zoom != 0)
        {
            mainCamera.fieldOfView+=zoom * speed;
            if(mainCamera.fieldOfView<=38)
            {
                mainCamera.fieldOfView = 38;
            }
            else if(mainCamera.fieldOfView>=95)
            {
                mainCamera.fieldOfView = 95;
            }
        }
    }
    public void GameStart()
    {
        isGameStart = true;
    }
    public void GameOver()
    {
        isGameStart = false;
    }
}
