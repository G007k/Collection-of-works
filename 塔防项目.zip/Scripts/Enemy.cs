using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int id;
    public int level;
    public int hp;
    public int attack;
    public int moveSpeed;
    public int gold;
    private int initMoveSpeed;
    private bool isMoving;
    private Animator animatorComp;
    private Rigidbody rigidbodyComp;
    private int pointIndex;
    private Transform nextPoint;
    private Transform[] pointList;
    private UIManager uiManager;
    private EnemyManager enemyManager;
    // Start is called before the first frame update
    void Awake()
    {
        animatorComp = this.GetComponent<Animator>();
        rigidbodyComp = this.GetComponent<Rigidbody>();
        uiManager = GameObject.Find("Canvas").GetComponent<UIManager>();
    }
    public void SetData(Transform[] path, EnemyManager enemyManager)
    {
        if(GameData.instance.levelID<=0)
        {
            return;
        }
        level = GameData.instance.levelID;
        hp = level * 100;
        attack = level *10;
        moveSpeed = level * 5;
        gold = level * 100;
        initMoveSpeed = moveSpeed;
        this.pointList = path;
        this.enemyManager = enemyManager;
        isMoving = true;
        pointIndex = 0;
    }
    private void Move()
    {
        if(!isMoving)
        {
            return;
        }
        if(nextPoint==null)
        {
            pointIndex=0;
            nextPoint = pointList[pointIndex];
        }
        if(Vector3.Distance(transform.position,nextPoint.position)>=1.0f)
        {
            transform.LookAt(nextPoint.position,Vector3.up);
            rigidbodyComp.velocity = transform.forward * moveSpeed;
        }
        else
        {
            pointIndex++;
            if(pointIndex >= pointList.Length)
            {
                isMoving = false;
                rigidbodyComp.velocity = Vector3.zero;
                if(GameData.instance.homeHP>0)
                {
                    GameData.instance.homeHP-=attack;
                    uiManager.UpadataBattleUI();
                }
                if(GameData.instance.homeHP <= 0)
                {
                    uiManager.ShowGameReult(isWin:false);
                    enemyManager.StopEnemyCreate();
                }
                this.gameObject.SetActive(false);
                return;
            }
            nextPoint = pointList[pointIndex];
        }
    }
    public void Stop()
    {
        isMoving = false;
        rigidbodyComp.Sleep();
        animatorComp.Play(stateName:"idle01");
    }
    // Update is called once per frame
    void Update()
    {
        Move();
    }
private void OnCollisionEnter(Collision collision)
{
    if(collision.gameObject.tag == "Bullet")
    {
        if(hp <= 0)
        {
            return;
        }
        hp -= 50;
        if(hp<=0)
        {
            isMoving = false;
            animatorComp.Play(stateName:"death_1");
            if(enemyManager!= null)
            {
                enemyManager.enemyList.Remove(this.gameObject);
            }
            this.GetComponent<Rigidbody>().isKinematic = true;
            this.GetComponent<Collider>().enabled = false;
            GameData.instance.killCount++;
            GameData.instance.coins += gold;
            uiManager.UpadataBattleUI();
            if(GameData.instance.killCount==GameData.instance.allEnemyCount)
            {
                uiManager.ShowGameReult(isWin:true);
            }
            CoinManager coinManager = GameObject.Find("CoinManager").GetComponent<CoinManager>();
            GameObject coinObj=coinManager.Create();
            coinObj.transform.position = this.transform.position+new Vector3(0,0.8f,0);
            coinObj.gameObject.SetActive(true);
            GameObject.Destroy(coinObj.gameObject,t:1.0f);
            GameObject.Destroy(this.gameObject,t:2.0f);
        }
    }
}

private void OnTriggerEnter(Collider other)
{
    if(other.gameObject.tag =="Effect")
    {
        if(initMoveSpeed==moveSpeed)
        {
        moveSpeed /= 2;
        }
    }
}
private void OnTriggerExit(Collider other)
{
    if(other.gameObject.tag == "Effect")
    {
        moveSpeed = initMoveSpeed;
    }
}
}