using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerBase : MonoBehaviour
{
    public Transform towerPosition;
    public GameObject tower;
    // Start is called before the first frame update
    void Start()
    {
       towerPosition = transform.Find("pos"); 
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
