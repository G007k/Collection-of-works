using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameData : MonoBehaviour
{
   public static GameData instance;
   public int levelID;
   public int coins;
   public int enemyCount;
   public int allEnemyCount;
   public int killCount;
   public float time;
   public int homeHP;
   
   public void Awake()
   {
    instance = this;
   }
   public void SetData(int level)
   {
    levelID = level;
    coins = level * 1000;
    enemyCount = level * 20;
    allEnemyCount = enemyCount;
    killCount = 0;
    time = 0;
    homeHP = level * 20;
   }

}
