using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{
    public List<GameObject>enemyPrefabList = new List<GameObject>();
    public Transform[] path;
    public List<GameObject> enemyList = new List<GameObject>();
    private bool isStop;
    private UIManager uiManager;
    // Start is called before the first frame update
    void Start()
    {
        uiManager = GameObject.Find("Canvas").GetComponent<UIManager>();
        for(int i = 0;i < enemyPrefabList.Count;i++)
        {
            Enemy enemy = enemyPrefabList[i].GetComponent<Enemy>();
            enemy.id = i;
        }
        StartCoroutine(routine:Create());
    }
    IEnumerator Create()
    {
        while(!isStop)
        {
            if(GameData.instance.enemyCount > 0)
            {
                GameData.instance.enemyCount--;
                uiManager.UpadataBattleUI();
                int index = Random.Range(0,enemyPrefabList.Count - 1);
                GameObject enemyObj = Instantiate(enemyPrefabList[index]);
                enemyObj.transform.position = path[0].position;
                enemyObj.transform.eulerAngles= path[0].eulerAngles;
                Enemy enemy = enemyObj.GetComponent<Enemy>();
                enemy.SetData(path, enemyManager:this);
                enemyList.Add(enemyObj);
            }
            if(GameData.instance.enemyCount<=0)
            {
                break;
            }
            yield return new WaitForSeconds(3.0f);
        }
    }
    public void StopEnemyCreate()
    {
        isStop = true;
        for(int i = 0;i < enemyList.Count;i++)
        {
            Enemy enemy = enemyList[i].GetComponent<Enemy>();
            enemy.Stop();
        }
        enemyList.Clear();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
